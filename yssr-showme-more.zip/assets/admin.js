jQuery(document).ready(function($) {
    // Funcionalidad adicional para el admin
    $('.wc-role-attr-preview-btn').on('click', function() {
        // Código para vista previa
    });
});
